/**
 * @file      nbody.h
 *
 * @author    xdovic01 \n
 *            Faculty of Information Technology \n
 *            Brno University of Technology \n
 *            jarosjir@fit.vutbr.cz
 *
 * @brief     PCG Assignment 2
 *            N-Body simulation in ACC
 *
 * @version   2021
 *
 * @date      11 November  2020, 11:22 (created) \n
 * @date      15 November  2021, 14:10 (revised) \n
 *
 */

#ifndef __NBODY_H__
#define __NBODY_H__

#include <cstdlib>
#include <cstdio>
#include  <cmath>
#include "h5Helper.h"

/// Gravity constant
constexpr float G = 6.67384e-11f;

/// Collision distance threshold
constexpr float COLLISION_DISTANCE = 0.01f;

/**
 * @struct float4
 * Structure that mimics CUDA float4
 */
struct float4
{
  float x;
  float y;
  float z;
  float w;
};

/// Define sqrtf from CUDA libm library
#pragma acc routine(sqrtf) seq

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                       Declare following structs / classes                                          //
//                                  If necessary, add your own classes / routines                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Structure with particle data
 */
struct Particles
{
  // Fill the structure holding the particle/s data
  // It is recommended to implement constructor / destructor and copyToGPU and copyToCPU routines
  float *restrict r_x;
  float *restrict r_y;
  float *restrict r_z;
  float *restrict v_x;
  float *restrict v_y;
  float *restrict v_z;
  float *restrict m;

  const int N;

  Particles(const int N): N(N)
  {
    this->r_x = new float[N];
    this->r_y = new float[N];
    this->r_z = new float[N];
    this->v_x = new float[N];
    this->v_y = new float[N];
    this->v_z = new float[N];
    this->m = new float[N];

    #pragma acc enter data copyin(this)
    #pragma acc enter data create(this->r_x[0:this->N])
    #pragma acc enter data create(this->r_y[0:this->N])
    #pragma acc enter data create(this->r_z[0:this->N])
    #pragma acc enter data create(this->v_x[0:this->N])
    #pragma acc enter data create(this->v_y[0:this->N])
    #pragma acc enter data create(this->v_z[0:this->N])
    #pragma acc enter data create(this->m[0:this->N])
  }

  ~Particles() noexcept
  {
    #pragma acc exit data delete(this->r_x)
    #pragma acc exit data delete(this->r_y)
    #pragma acc exit data delete(this->r_z)
    #pragma acc exit data delete(this->v_x)
    #pragma acc exit data delete(this->v_y)
    #pragma acc exit data delete(this->v_z)
    #pragma acc exit data delete(this->m)
    #pragma acc exit data delete(this)

    delete[] this->r_x;
    delete[] this->r_y;
    delete[] this->r_z;
    delete[] this->v_x;
    delete[] this->v_y;
    delete[] this->v_z;
    delete[] this->m;
  }

  void accUpdateSelf()
  {
    #pragma acc update host(this->r_x[0:this->N])
    #pragma acc update host(this->r_y[0:this->N])
    #pragma acc update host(this->r_z[0:this->N])
    #pragma acc update host(this->v_x[0:this->N])
    #pragma acc update host(this->v_y[0:this->N])
    #pragma acc update host(this->v_z[0:this->N])
    #pragma acc update host(this->m[0:this->N])
  }

  void accUpdateDevice()
  {
    #pragma acc update device(this->r_x[0:this->N])
    #pragma acc update device(this->r_y[0:this->N])
    #pragma acc update device(this->r_z[0:this->N])
    #pragma acc update device(this->v_x[0:this->N])
    #pragma acc update device(this->v_y[0:this->N])
    #pragma acc update device(this->v_z[0:this->N])
    #pragma acc update device(this->m[0:this->N])
  }
};// end of Particles
//----------------------------------------------------------------------------------------------------------------------

/**
 * @struct Velocities
 * Velocities of the particles
 */
struct Velocities
{
  // Fill the structure holding the particle/s data
  // It is recommended to implement constructor / destructor and copyToGPU and copyToCPU routines
  float *restrict x;
  float *restrict y;
  float *restrict z;

  const int N;

  Velocities(const int N): N(N)
  {
    this->x = (float*) malloc(N * sizeof(float));
    this->y = (float*) malloc(N * sizeof(float));
    this->z = (float*) malloc(N * sizeof(float));

    #pragma acc enter data copyin(this)
    #pragma acc enter data create(this->x[0:this->N])
    #pragma acc enter data create(this->z[0:this->N])
    #pragma acc enter data create(this->y[0:this->N])
  }

  ~Velocities() noexcept
  {
    #pragma acc exit data delete(this->x)
    #pragma acc exit data delete(this->y)
    #pragma acc exit data delete(this->x)
    #pragma acc exit data delete(this)

    delete[] this->x;
    delete[] this->y;
    delete[] this->z;
  }

  void accUpdateSelf()
  {
    #pragma acc update host(this->x[0:this->N])
    #pragma acc update host(this->y[0:this->N])
    #pragma acc update host(this->z[0:this->N])
  }

  void accUpdateDevice()
  {
    #pragma acc update device(this->x[0:this->N])
    #pragma acc update device(this->y[0:this->N])
    #pragma acc update device(this->z[0:this->N])
  }
};// end of Velocities
//----------------------------------------------------------------------------------------------------------------------

/**
 * Compute gravitation velocity
 * @param [in]  p        - Particles
 * @param [out] tmp_vel  - Temporal velocity
 * @param [in ] N        - Number of particles
 * @param [in]  dt       - Time step size
 */
void calculate_gravitation_velocity(const Particles& p,
                                    Velocities&      tmp_vel,
                                    const int        N,
                                    const float      dt);

/**
 * Calculate collision velocity
 * @param [in]  p        - Particles
 * @param [out] tmp_vel  - Temporal velocity
 * @param [in ] N        - Number of particles
 * @param [in]  dt       - Time step size
 */
void calculate_collision_velocity(const Particles& p,
                                  Velocities&      tmp_vel,
                                  const int        N,
                                  const float      dt);
 
/**
 * Update particle position
 * @param [in]  p        - Particles
 * @param [out] tmp_vel  - Temporal velocity
 * @param [in ] N        - Number of particles
 * @param [in]  dt       - Time step size
 */
void update_particle(const Particles& p,
                     Velocities&      tmp_vel,
                     const int        N,
                     const float      dt);



/**
 * Compute center of gravity - implement in steps 3 and 4.
 * @param [in] p - Particles
 * @param [in] N - Number of particles
 * @return Center of Mass [x, y, z] and total weight[w]
 */
float4 centerOfMassGPU(const Particles& p,
                       const int        N);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Compute center of mass on CPU
 * @param memDesc
 * @return centre of gravity
 */
float4 centerOfMassCPU(MemDesc& memDesc);

#endif /* __NBODY_H__ */
