/**
 * @file      nbody.cpp
 *
 * @author    xdovic01 \n
 *            Faculty of Information Technology \n
 *            Brno University of Technology \n
 *            jarosjir@fit.vutbr.cz
 *
 * @brief     PCG Assignment 2
 *            N-Body simulation in ACC
 *
 * @version   2021
 *
 * @date      11 November  2020, 11:22 (created) \n
 * @date      15 November  2021, 14:10 (revised) \n
 *
 */

#include <math.h>
#include <cfloat>
#include "nbody.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                       Declare following structs / classes                                          //
//                                  If necessary, add your own classes / routines                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// Compute gravitation velocity
void calculate_gravitation_velocity(const Particles& p,
                                    Velocities&      tmp_vel,
                                    const int        N,
                                    const float      dt)
{ 
  #pragma acc parallel loop gang present(p, tmp_vel)
  for (int i = 0; i < N; ++i)
  {
    const float r_x = p.r_x[i];
    const float r_y = p.r_y[i];
    const float r_z = p.r_z[i];

    float tmp_x = .0f; float tmp_y = .0f; float tmp_z = .0f;
    #pragma acc loop vector reduction(+:tmp_z,tmp_y,tmp_x)
    for (int j = 0; j < N; j++)
    {
      const float dx = r_x - p.r_x[j];
      const float dy = r_y - p.r_y[j];
      const float dz = r_z - p.r_z[j];

      const float r = sqrtf(dx * dx + dy * dy + dz * dz);

      if (r > COLLISION_DISTANCE)
      {
        tmp_x += -G * p.m[j] * dx / (r * r * r + FLT_MIN) * dt;
        tmp_y += -G * p.m[j] * dy / (r * r * r + FLT_MIN) * dt;
        tmp_z += -G * p.m[j] * dz / (r * r * r + FLT_MIN) * dt;
      }
    }

    tmp_vel.x[i] = tmp_x;
    tmp_vel.y[i] = tmp_y;
    tmp_vel.z[i] = tmp_z;
  }
}// end of calculate_gravitation_velocity
//----------------------------------------------------------------------------------------------------------------------

void calculate_collision_velocity(const Particles& p,
                                  Velocities&      tmp_vel,
                                  const int        N,
                                  const float      dt)
{
  
  #pragma acc parallel loop gang present(p, tmp_vel)
  for (int i = 0; i < N; ++i)
  {
    const float r_x = p.r_x[i];
    const float r_y = p.r_y[i];
    const float r_z = p.r_z[i];

    float tmp_x = .0f; float tmp_y = .0f; float tmp_z = .0f;
    #pragma acc loop vector reduction(+:tmp_z,tmp_y,tmp_x)
    for (int j = 0; j < N; j++)
    {
      const float dx = r_x - p.r_x[j];
      const float dy = r_y - p.r_y[j];
      const float dz = r_z - p.r_z[j];

      const float r = sqrtf(dx * dx + dy * dy + dz * dz);

      if (r > .0f && r < COLLISION_DISTANCE)
      {
        tmp_x += 2 * p.m[j] * (p.v_x[j] - p.v_x[i]) / (p.m[i] + p.m[j]);
        tmp_y += 2 * p.m[j] * (p.v_y[j] - p.v_y[i]) / (p.m[i] + p.m[j]);
        tmp_z += 2 * p.m[j] * (p.v_z[j] - p.v_z[i]) / (p.m[i] + p.m[j]);
      }
    }

    tmp_vel.x[i] += tmp_x;
    tmp_vel.y[i] += tmp_y;
    tmp_vel.z[i] += tmp_z;
  }
}// end of calculate_collision_velocity
//----------------------------------------------------------------------------------------------------------------------

/// Update particle position
void update_particle(const Particles& p,
                     Velocities&      tmp_vel,
                     const int        N,
                     const float      dt)
{
  #pragma acc parallel loop gang vector present(p, tmp_vel)
  for (int i = 0; i < N; ++i)
  {
    p.v_x[i] += tmp_vel.x[i];
    p.r_x[i] += p.v_x[i] * dt;

    p.v_y[i] += tmp_vel.y[i];
    p.r_y[i] += p.v_y[i] * dt;

    p.v_z[i] += tmp_vel.z[i];
    p.r_z[i] += p.v_z[i] * dt;
  }
}// end of update_particle
//----------------------------------------------------------------------------------------------------------------------



/// Compute center of gravity
float4 centerOfMassGPU(const Particles& p,
                       const int        N)
{

  return {0.0f, 0.0f, 0.0f, 0.0f};
}// end of centerOfMassGPU
//----------------------------------------------------------------------------------------------------------------------

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// Compute center of mass on CPU
float4 centerOfMassCPU(MemDesc& memDesc)
{
  float4 com = {0 ,0, 0, 0};

  for(int i = 0; i < memDesc.getDataSize(); i++)
  {
    // Calculate the vector on the line connecting points and most recent position of center-of-mass
    const float dx = memDesc.getPosX(i) - com.x;
    const float dy = memDesc.getPosY(i) - com.y;
    const float dz = memDesc.getPosZ(i) - com.z;

    // Calculate weight ratio only if at least one particle isn't massless
    const float dw = ((memDesc.getWeight(i) + com.w) > 0.0f)
                          ? ( memDesc.getWeight(i) / (memDesc.getWeight(i) + com.w)) : 0.0f;

    // Update position and weight of the center-of-mass according to the weight ration and vector
    com.x += dx * dw;
    com.y += dy * dw;
    com.z += dz * dw;
    com.w += memDesc.getWeight(i);
  }
  return com;
}// end of centerOfMassCPU
//----------------------------------------------------------------------------------------------------------------------
