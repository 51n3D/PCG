/**
 * @file      nbody.cpp
 *
 * @author    xdovic01 \n
 *            Faculty of Information Technology \n
 *            Brno University of Technology \n
 *            jarosjir@fit.vutbr.cz
 *
 * @brief     PCG Assignment 2
 *            N-Body simulation in ACC
 *
 * @version   2021
 *
 * @date      11 November  2020, 11:22 (created) \n
 * @date      15 November  2021, 14:10 (revised) \n
 *
 */

#include <math.h>
#include <cfloat>
#include "nbody.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                       Declare following structs / classes                                          //
//                                  If necessary, add your own classes / routines                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// Compute velocity
void calculate_velocity(const Particles& p_in,
                        Particles&       p_out,
                        const int        N,
                        const float      dt)
{
  #pragma acc parallel loop gang present(p_in, p_out)
  for (int i = 0; i < N; ++i)
  {
    const float r_x = p_in.r_x[i];
    const float r_y = p_in.r_y[i];
    const float r_z = p_in.r_z[i];

    float tmp_x = .0f, tmp_y = .0f, tmp_z = .0f;
    #pragma acc loop vector reduction(+:tmp_z,tmp_y,tmp_x)
    for (int j = 0; j < N; j++)
    {
      const float dx = r_x - p_in.r_x[j];
      const float dy = r_y - p_in.r_y[j];
      const float dz = r_z - p_in.r_z[j];

      const float r = sqrtf(dx * dx + dy * dy + dz * dz);

      if (r > COLLISION_DISTANCE)
      {
        tmp_x += -G * p_in.m[j] * dx / (r * r * r + FLT_MIN) * dt;
        tmp_y += -G * p_in.m[j] * dy / (r * r * r + FLT_MIN) * dt;
        tmp_z += -G * p_in.m[j] * dz / (r * r * r + FLT_MIN) * dt;
      } 
      else if (r > .0f && r < COLLISION_DISTANCE)
      {
        tmp_x += 2 * p_in.m[j] * (p_in.v_x[j] - p_in.v_x[i]) / (p_in.m[i] + p_in.m[j]);
        tmp_y += 2 * p_in.m[j] * (p_in.v_y[j] - p_in.v_y[i]) / (p_in.m[i] + p_in.m[j]);
        tmp_z += 2 * p_in.m[j] * (p_in.v_z[j] - p_in.v_z[i]) / (p_in.m[i] + p_in.m[j]);
      }
    }

    p_out.v_x[i] = p_in.v_x[i] + tmp_x;
    p_out.r_x[i] = p_in.r_x[i] + p_out.v_x[i] * dt;

    p_out.v_y[i] = p_in.v_y[i] + tmp_y;
    p_out.r_y[i] = p_in.r_y[i] + p_out.v_y[i] * dt;

    p_out.v_z[i] = p_in.v_z[i] + tmp_z;
    p_out.r_z[i] = p_in.r_z[i] + p_out.v_z[i] * dt;
  }
}// end of calculate_velocity
//----------------------------------------------------------------------------------------------------------------------


/// Compute center of gravity
float4 centerOfMassGPU(const Particles& p,
                       float4*    tmp_com, 
                       const int        N)
{
  #pragma acc parallel loop gang vector present(p, tmp_com)
  for (size_t i = 0; i < N; ++i)
  {
    const float dw = p.m[i] > .0f ? 1.f : .0f;
    tmp_com[i] = { p.r_x[i] * dw, p.r_y[i] * dw, p.r_z[i] * dw, p.m[i] };
  }

  size_t nearest_pow2 = (1 << static_cast<size_t>(ceil(log2(N))));
  for (size_t stride = nearest_pow2 >> 1; stride > 0; stride >>= 1)
  {
    #pragma acc parallel loop gang vector present(p, tmp_com)
    for (size_t i = 0; i < stride; i++)
    {
      if (i + stride < N)
      {
        const float m = tmp_com[i + stride].w;
        const float dw = m + tmp_com[i].w > .0f ? m / (m + tmp_com[i].w) : .0f;

        tmp_com[i].x += (tmp_com[i + stride].x - tmp_com[i].x) * dw;
        tmp_com[i].y += (tmp_com[i + stride].y - tmp_com[i].y) * dw;
        tmp_com[i].z += (tmp_com[i + stride].z - tmp_com[i].z) * dw;
        tmp_com[i].w += m;
      }
    }
  }

  #pragma acc update host(tmp_com[:1])
  return tmp_com[0];
}// end of centerOfMassGPU
//----------------------------------------------------------------------------------------------------------------------

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// Compute center of mass on CPU
float4 centerOfMassCPU(MemDesc& memDesc)
{
  float4 com = {0 ,0, 0, 0};

  for(int i = 0; i < memDesc.getDataSize(); i++)
  {
    // Calculate the vector on the line connecting points and most recent position of center-of-mass
    const float dx = memDesc.getPosX(i) - com.x;
    const float dy = memDesc.getPosY(i) - com.y;
    const float dz = memDesc.getPosZ(i) - com.z;

    // Calculate weight ratio only if at least one particle isn't massless
    const float dw = ((memDesc.getWeight(i) + com.w) > 0.0f)
                          ? ( memDesc.getWeight(i) / (memDesc.getWeight(i) + com.w)) : 0.0f;

    // Update position and weight of the center-of-mass according to the weight ration and vector
    com.x += dx * dw;
    com.y += dy * dw;
    com.z += dz * dw;
    com.w += memDesc.getWeight(i);
  }
  return com;
}// end of centerOfMassCPU
//----------------------------------------------------------------------------------------------------------------------
