/**
 * @file      main.cpp
 *
 * @author    xdovic01 \n
 *            Faculty of Information Technology \n
 *            Brno University of Technology \n
 *            jarosjir@fit.vutbr.cz
 *
 * @brief     PCG Assignment 2
 *            N-Body simulation in ACC
 *
 * @version   2021
 *
 * @date      11 November  2020, 11:22 (created) \n
 * @date      15 November  2021, 14:03 (revised) \n
 *
 */

#include <chrono>
#include <cstdio>
#include <cmath>

#include "nbody.h"
#include "h5Helper.h"

/**
 * Main routine of the project
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char **argv)
{
  // Parse command line parameters
  if (argc != 7)
  {
    printf("Usage: nbody <N> <dt> <steps> <write intesity> <input> <output>\n");
    exit(EXIT_FAILURE);
  }

  const int   N         = std::stoi(argv[1]);
  const float dt        = std::stof(argv[2]);
  const int   steps     = std::stoi(argv[3]);
  const int   writeFreq = (std::stoi(argv[4]) > 0) ? std::stoi(argv[4]) : 0;

  printf("N: %d\n", N);
  printf("dt: %f\n", dt);
  printf("steps: %d\n", steps);

  const size_t recordsNum = (writeFreq > 0) ? (steps + writeFreq - 1) / writeFreq : 0;


  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //                                         Code to be implemented                                                   //
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  // 1.  Memory allocation on CPU
  Particles particles[] = { Particles(N), Particles(N) };
  
  // 2. Create memory descriptor
  /*
   * Caution! Create only after CPU side allocation
   * parameters:
   *                                    Stride of two               Offset of the first
   *             Data pointer           consecutive elements        element in floats,
   *                                    in floats, not bytes        not bytes
   */
  MemDesc md(
      particles[0].r_x,                1,                          0,            // Position in X
      particles[0].r_y,                1,                          0,            // Position in Y
      particles[0].r_z,                1,                          0,            // Position in Z
      particles[0].v_x,                1,                          0,            // Velocity in X
      particles[0].v_y,                1,                          0,            // Velocity in Y
      particles[0].v_z,                1,                          0,            // Velocity in Z
      particles[0].m,                1,                          0,            // Weight
      N,                                                                // Number of particles
      recordsNum);                                                      // Number of records in output file



  H5Helper h5Helper(argv[5], argv[6], md);

  // Read data
  try
  {
    h5Helper.init();
    h5Helper.readParticleData();
  } catch (const std::exception& e)
  {
    std::cerr<<e.what()<<std::endl;
    return EXIT_FAILURE;
  }

  particles[1] = particles[0];
  // 3. Copy data to GPU
  particles[0].accUpdateDevice();
  particles[1].accUpdateDevice();

  float4* tmp_com = new float4[N];
  #pragma acc enter data create(tmp_com[0:N])

  // Start the time
  auto startTime = std::chrono::high_resolution_clock::now();

  // 4. Run the loop - calculate new Particle positions.
  for (int s = 0; s < steps; s++)
  {
    calculate_velocity(particles[s % 2], particles[(s + 1) % 2], N, dt);
    float4 comOnGPU = centerOfMassGPU(particles[(s + 1) % 2], tmp_com, N);

    /// In step 4 - fill in the code to store Particle snapshots.
    if (writeFreq > 0 && (s % writeFreq == 0))
    {
      #pragma acc wait(COMPUTE_VEL)
      particles[s % 2].accUpdateSelf();

      #pragma acc wait(TRANSFER_VEL)
      particles[0] = particles[s % 2];
      h5Helper.writeParticleData(s / writeFreq);

      #pragma acc wait(TRANSFER_COM)
      h5Helper.writeCom(comOnGPU.x, comOnGPU.y, comOnGPU.z, comOnGPU.w, s / writeFreq);
    }

    #pragma acc wait(COMPUTE_VEL)
  }// for s ...

  // 5. In steps 3 and 4 -  Compute center of gravity
  float4 comOnGPU = centerOfMassGPU(particles[steps % 2], tmp_com, N);
  #pragma acc exit data delete(tmp_com)
  delete[] tmp_com;

  // Stop watchclock
  const auto   endTime = std::chrono::high_resolution_clock::now();
  const double time    = (endTime - startTime) / std::chrono::milliseconds(1);
  printf("Time: %f s\n", time / 1000);


  // 5. Copy data from GPU back to CPU.
  particles[steps % 2].accUpdateSelf();
  particles[0] = particles[steps % 2];

  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  /// Calculate center of gravity
  float4 comOnCPU = centerOfMassCPU(md);

  std::cout<<"Center of mass on CPU:"<<std::endl
    << comOnCPU.x <<", "
    << comOnCPU.y <<", "
    << comOnCPU.z <<", "
    << comOnCPU.w
    << std::endl;

  #pragma acc wait(TRANSFER_COM)
  std::cout<<"Center of mass on GPU:"<<std::endl
    << comOnGPU.x <<", "
    << comOnGPU.y <<", "
    << comOnGPU.z <<", "
    << comOnGPU.w
    <<std::endl;

  // Store final positions of the particles into a file
  h5Helper.writeComFinal(comOnGPU.x, comOnGPU.y, comOnGPU.z, comOnGPU.w);
  h5Helper.writeParticleDataFinal();

  return EXIT_SUCCESS;
}// end of main
//----------------------------------------------------------------------------------------------------------------------

