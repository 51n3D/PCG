#!/bin/bash
ml CUDA/11.0.2-GCC-9.3.0 HDF5/1.12.0-iimpi-2020a
